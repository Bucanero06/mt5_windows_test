# Algorithmic Trading 

This Repository is created to store all the code to teach algorithmic trading with Python and Metatrader 5